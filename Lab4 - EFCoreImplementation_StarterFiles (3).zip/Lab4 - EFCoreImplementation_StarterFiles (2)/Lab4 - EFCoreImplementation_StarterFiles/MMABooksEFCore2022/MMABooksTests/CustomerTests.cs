using System.Collections.Generic;
using System.Linq;
using System;

using NUnit.Framework;
using MMABooksEFClasses.MarisModels;
using Microsoft.EntityFrameworkCore; //add model here in notes
using System.Reflection.Emit;

namespace MMABooksTests
{
    [TestFixture]
    public class CustomerTests
    {

        MMABooksContext dbContext;
        Customer? c;
        List<Customer>? customers;

        [SetUp]
        public void Setup()
        {
            dbContext = new MMABooksContext();
            dbContext.Database.ExecuteSqlRaw("call usp_testingResetData()");
        }

        [Test]
        public void GetAllTest()
        {
            customers = dbContext.Customers.OrderBy(c => c.CustomerId).ToList();
            Assert.AreEqual(696, customers.Count);
            Assert.AreEqual(1, customers[0].CustomerId); //was "Molunguri, A" where 1 is
            PrintAll(customers);
        }

        [Test]
        public void GetByPrimaryKeyTest()
        {
            c = dbContext.Customers.Find("Molunguri, A");

            Assert.IsNotNull(c);
            Assert.AreEqual("Molunguri, A", c.Name);
            Assert.AreEqual("Birmingham", c.City);
            Console.WriteLine(c);
        }

        [Test]
        public void GetUsingWhere()
        {
            // get a list of all of the customers who live in OR
            customers = dbContext.Customers.Where(c => c.StateCode.Equals("OR")).OrderBy(c => c.Name).ToList();
            Assert.AreEqual(5, customers.Count);
            Assert.AreEqual("Erpenbach, Lee", customers[0].Name);
            PrintAll(customers); //issue with models?
        }

        [Test]
        public void GetWithInvoicesTest()
        {
            // get the customer whose id is 20 and all of the invoices for that customer
            c = dbContext.Customers.Include("Invoices").Where(c => c.CustomerId == 20).SingleOrDefault();
            Assert.IsNotNull(c);
            Assert.AreEqual("Chamberland, Sarah", c.Name); //was a different name, and was c.City
            Assert.AreEqual(3, c.Invoices.Count);// was five
        }

        [Test]
        public void GetWithJoinTest()
        {
            // get a list of objects that include the customer id, name, statecode and statename
            var customers = dbContext.Customers.Join(
               dbContext.States,
               c => c.StateCode,
               s => s.StateCode,
               (c, s) => new { c.CustomerId, c.Name, c.StateCode, s.StateName }).OrderBy(r => r.StateName).ToList();
            Assert.AreEqual(696, customers.Count);
            // I wouldn't normally print here but this lets you see what each object looks like
            foreach (var c in customers)
            {
                Console.WriteLine(c);
            }
        }

        [Test]
        public void DeleteTest()
        {
            c = dbContext.Customers.Find(1);//cant use actual name have to use numbers bc int
            dbContext.Customers.Remove(c);
            dbContext.SaveChanges();
            Assert.IsNull(dbContext.Customers.Find(1));

        }

        [Test]
        public void CreateTest()
        {
            // Create a new customer
            Customer c = new Customer();
            c.Name = "Barbie";
            c.Address = "123 Pretty Street";
            c.City = "Barbia";
            c.StateCode = "OR";
            c.ZipCode = "97408";
            var existingState = dbContext.States.Find(c.StateCode);
            if (existingState == null)
            {
                Assert.Fail($"StateCode '{c.StateCode}' does not exist in the States table.");
            }

            // Add the customer to the context
            dbContext.Customers.Add(c);

            // Save changes to the database
            dbContext.SaveChanges();

            // Find the customer using the correct DbSet property
            Customer c2 = dbContext.Customers.Find(c.CustomerId); // Assuming CustomerId is the primary key

            // Assert that the customer was found
            Assert.NotNull(c2);

            // Assert the properties of the customer
            Assert.AreEqual("123 Pretty Street", c2.Address);
            Assert.AreEqual("OR", c2.StateCode);
            Assert.AreEqual("97408", c2.ZipCode);


        }

        [Test]
        public void UpdateTest()
        {
            c = dbContext.Customers.Find(2);
            c.Name = "Oregon Jones";
            c.Address = "789 Street";
            c.City = "Kenia";
            c.StateCode = "WA";
            c.ZipCode = "97401";
            dbContext.Update(c);

            dbContext.SaveChanges();
            c = dbContext.Customers.Find(2);
            Assert.AreEqual("Oregon Jones", c.Name);
            Assert.AreEqual("97401", c.ZipCode);
        }

        public void PrintAll(List<Customer> customers)
        {
            foreach (Customer c in customers) //this isnt in products, put it there
            {
                Console.WriteLine(c);
            }
        }

    }
}