using System.Collections.Generic;
using System.Linq;
using System;

using NUnit.Framework;
using MMABooksEFClasses.MarisModels;
using Microsoft.EntityFrameworkCore;

namespace MMABooksTests
{
    [TestFixture]
    public class ProductTests
    {

        MMABooksContext dbContext;
        Products? p;
        List<Products>? products;

        [SetUp]
        public void Setup()
        {
            dbContext = new MMABooksContext();
            dbContext.Database.ExecuteSqlRaw("call usp_testingResetData()");
        }

        [Test]
        public void GetAllTest()
        {
            products = dbContext.Products.OrderBy(p => p.ProductCode).ToList();
            Assert.AreEqual(16, products.Count); //696 is not right, how many products are there?
            Assert.AreEqual("A4CS", products[0].ProductCode);
            PrintAll(products);
        }

        [Test]
        public void GetByPrimaryKeyTest()
        {
            p = dbContext.Products.Find("A4CS");

            Assert.IsNotNull(p);
            Assert.AreEqual("A4CS", p.ProductCode);
            Assert.AreEqual(56.50M, p.UnitPrice);
            Console.WriteLine(p);
        }

        [Test]
        public void GetUsingWhere()
        {
            // get a list of all of the products that have a unit price of 56.50
            products = dbContext.Products.Where(p => p.UnitPrice.Equals(56.50M)).OrderBy(p => p.UnitPrice).ToList(); //should I order by unit price? will that sort high to low or low to high
            Assert.AreEqual(7, products.Count); //why is five here //why is getting 7??
            Assert.AreEqual("Murach's ASP.NET 4 Web Programming with C# 2010", products[0].Description); //gets an error about mari's models
            PrintAll(products);
        }

        [Test]
        public void GetWithCalculatedFieldTest()
        {
            // get a list of objects that include the productcode, unitprice, quantity and inventoryvalue
            var products = dbContext.Products.Select(
            p => new { p.ProductCode, p.UnitPrice, p.OnHandQuantity, Value = p.UnitPrice * p.OnHandQuantity }).
            OrderBy(p => p.ProductCode).ToList();
            Assert.AreEqual(16, products.Count);
            foreach (var p in products)
            {
                Console.WriteLine(p);
            }
        }

        [Test]
        public void DeleteTest()
        {
            p = dbContext.Products.Find("ADC4");
            dbContext.Products.Remove(p);
            dbContext.SaveChanges();
            Assert.IsNull(dbContext.Products.Find("ADC4")); //what does this line do
        }

        [Test]
        public void CreateTest()
        {
            Products p = new Products();
            p.ProductCode = "ZA32";
            p.Description = "Coding For Bears"; //what, dunno why error
            p.UnitPrice = 14.99M;
            p.OnHandQuantity = 1;
            dbContext.Add(p);
            dbContext.SaveChanges();

            Assert.NotNull(dbContext.Products.Find("ZA32"));
            Products p2 = dbContext.Products.Find("ZA32");
            Assert.AreEqual("Coding For Bears", p2.Description);
            Assert.AreEqual(p.UnitPrice, p2.UnitPrice);

         //   Assert.NotNull(dbContext.Products.Find("ZA32"));
          //  Products p1 = dbContext.Products.Find("ZA32");//p2 or p1
          //  Assert.AreEqual("Coding for bears", p2.UnitPrice);
           // Assert.AreEqual(p.UnitPrice, p2.UnitPrice);
        }

        [Test]
        public void UpdateTest()
        {
            p = dbContext.Products.Find("A4CS");
            p.Description = "New Edition";
            p.OnHandQuantity = 97401;
            p.UnitPrice = 9.99M;
            dbContext.Update(p);
            dbContext.SaveChanges();

        }
        public void PrintAll(List<Products> products)
        {
            foreach (Products p in products)
            {
                Console.WriteLine(p);
            }
        }

    }
}